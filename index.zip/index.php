<?php echo "Hello world!" ?>
